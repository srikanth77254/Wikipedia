document.querySelector('.search-bar').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        const query = e.target.value.trim();
        if (query.length > 0) {
            window.location.href = `https://en.wikipedia.org/wiki/Special:Search?search=${query}`;
        }
    }
});